SHA-256 hash
Author : Shengqi Suizhu

A java application that implements SHA256
The code is created based on the pseudocode provided in Wikipeida, also the pdf in this current folder.
most functions are just normal logical operations, althought there are more functions defined
which can be found in the pdf at page 6.
The encryption cycles depends on the length of String bits.

A executable jar file is also included in the zip file

====================================


File Archive:
README.md(This file)
SHA256.java(The major SHA256 algorithm)
SHA256TEST.java(main method)
SHA256.jar(runnable jar file)
SHA256.pdf(detailed SHA256 explanation doc, with pseudocode inside)